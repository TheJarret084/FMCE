package funkin.backend.chart;

import flixel.util.FlxColor;

typedef ChartData = {
	public var strumLines:Array<ChartStrumLine>;
	public var events:Array<ChartEvent>;
	public var meta:ChartMetaData;
	public var stage:String;
	public var noteTypes:Array<String>;
	public var ?bookmarks:Array<ChartBookmark>;
	/** `action_packs` de events.json: cada pack es una lista de acciones que corre un `RunActionPack`. */
	public var ?actionPacks:Array<ChartActionPack>;

	public var ?chartVersion:String;
}

typedef ChartMetaData = {
	public var name:String;
	public var ?displayName:String;

	public var ?bpm:Float;
	public var ?beatsPerMeasure:Float;
	public var ?stepsPerBeat:Int;


	public var ?color:FlxColor;

	/** Sprites (carpeta en `<nivel>/sprites/`) de los iconos de la barra de vida: `meta.json` > `icons.P1` / `icons.P2`. */
	public var ?iconPlayer:String;
	public var ?iconOpponent:String;


	public var ?instSuffix:String;
	public var ?vocalsSuffix:String;
	public var ?needsVoices:Bool;
}

typedef ChartStrumLine = {
	var characters:Array<String>;
	var type:ChartStrumLineType;
	var notes:Array<ChartNote>;
	var position:String;
	var ?visible:Null<Bool>;
	var ?strumPos:Array<Float>;
	var ?strumScale:Float;
	var ?strumSpacing:Float;
	var ?vocalsSuffix:String;
	var ?keyCount:Int; // default=4

	var ?strumLinePos:Float; // Backwards compatibility
}

typedef ChartNote = {
	var time:Float; // time at which the note will be hit (ms)
	var id:Int; // strum id of the note
	var type:Int; // type (int) of the note
	var sLen:Float; // sustain length of the note (ms)
	var ?onPress:Int; // action pack (events.json) al acertar la nota; -1 o falta = ninguno
	var ?onMiss:Int; // action pack (events.json) al fallar la nota
}

typedef ChartBookmark = {
	var time:Float;
	var name:String;
	var color:String;
}

typedef ChartActionPack = {
	var actions:Array<ChartEvent>;
	var ?name:String;
}

typedef ChartEvent = {
	/** Accion que el charter no conoce: se guarda tal cual vino. */
	var ?raw:Dynamic;
	var name:String;
	var time:Float;
	var params:Array<Dynamic>;

}

enum abstract ChartStrumLineType(Int) from Int to Int {
	/**
	 * STRUMLINE IS MARKED AS OPPONENT - WILL BE PLAYED BY CPU, OR PLAYED BY PLAYER IF OPPONENT MODE IS ON
	 */
	var OPPONENT = 0;
	/**
	 * STRUMLINE IS MARKED AS PLAYER - WILL BE PLAYED AS PLAYER, OR PLAYED AS CPU IF OPPONENT MODE IS ON
	 */
	var PLAYER = 1;
	/**
	 * STRUMLINE IS MARKED AS ADDITIONAL - WILL BE PLAYED AS CPU EVEN IF OPPONENT MODE IS ENABLED
	 */
	var ADDITIONAL = 2;
}